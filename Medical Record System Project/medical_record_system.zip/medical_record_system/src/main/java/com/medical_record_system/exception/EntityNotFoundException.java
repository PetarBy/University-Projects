package com.medical_record_system.exception;

public class EntityNotFoundException extends RuntimeException{
    
}
