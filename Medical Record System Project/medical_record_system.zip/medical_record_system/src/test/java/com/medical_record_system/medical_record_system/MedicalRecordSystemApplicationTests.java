package com.medical_record_system.medical_record_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicalRecordSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
